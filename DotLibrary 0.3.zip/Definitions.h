#pragma once

struct colorTemplate {
	int r = 0;
	int g = 0;
	int b = 0;
	int a = 255;
};

struct coordinateTemplate {
	int x = 20;
	int y = 20;
};

struct sizeTemplate {
	int w;
	int h;
};